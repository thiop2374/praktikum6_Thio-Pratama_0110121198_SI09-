<?php
class Dosen_Model extends CI_Model {
    public $id;
    public $nidn;
    public $pendidikan;

} 
